package hell.models.heroes;

public class Assassin extends AbstractHero{

    private int strength;
    private int agility;
    private int intelligence;
    private int hitPoints;
    private int damage;

    public Assassin(String name) {
        super(name);
        this.strength = 25;
        this.agility = 100;
        this.intelligence = 15;
        this.hitPoints = 150;
        this.damage = 300;
    }
}
