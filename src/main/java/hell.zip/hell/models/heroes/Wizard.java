package hell.models.heroes;

public class Wizard extends AbstractHero{

    private int strength;
    private int agility;
    private int intelligence;
    private int hitPoints;
    private int damage;

    public Wizard(String name) {
        super(name);
        this.strength = 25;
        this.agility = 25;
        this.intelligence = 100;
        this.hitPoints = 100;
        this.damage = 250;
    }
}
