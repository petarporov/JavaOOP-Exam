package hell.models.heroes;

public class Barbarian extends AbstractHero{

    private int strength;
    private int agility;
    private int intelligence;
    private int hitPoints;
    private int damage;

    public Barbarian(String name) {
        super(name);
        this.strength = 90;
        this.agility = 25;
        this.intelligence = 10;
        this.hitPoints = 350;
        this.damage = 150;
    }
}
